@@ -0,0 +1,30 @@
#!/usr/bin/env python
import os
import django

# Configurar Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'market.settings')
django.setup()

from app.models import admin, Cajero
from django.contrib.auth.hashers import make_password

# Hashear contraseña del administrador
try:
    admin_user = admin.objects.get(email='caansobu2@gmail.com')
    admin_user.password = make_password('1234')
    admin_user.save()
    print(f"✓ Contraseña del administrador hasheada")
except admin.DoesNotExist:
    print("✗ Administrador no encontrado")

# Hashear contraseña del cajero
try:
    cajero_user = Cajero.objects.get(correo='camilosolerbu@gmail.com')
    cajero_user.password = make_password('1234')
    cajero_user.save()
    print(f"✓ Contraseña del cajero hasheada")
except Cajero.DoesNotExist:
    print("✗ Cajero no encontrado")

print("\n¡Contraseñas actualizadas exitosamente!")

import os
import django
from django.contrib.auth.hashers import make_password

# Configuración de Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'market.settings')
django.setup()

from app.models import admin, Cajero

def create_or_update_users():
    # Datos según tu README
    users_data = [
        {'model': admin, 'email': 'caansobu2@gmail.com', 'pass': '1234', 'name_field': 'email'},
        {'model': Cajero, 'email': 'camilosolerbu@gmail.com', 'pass': '1234', 'name_field': 'correo'}
    ]

    for data in users_data:
        try:
            # Buscamos si ya existe el usuario
            filter_kwargs = {data['name_field']: data['email']}
            user = data['model'].objects.filter(**filter_kwargs).first()
            
            hashed_pw = make_password(data['pass'])

            if user:
                user.password = hashed_pw
                user.save()
                print(f"✓ Usuario {data['email']} actualizado con contraseña cifrada.")
            else:
                # Si no existe, lo creamos (ajustado a tus modelos)
                if data['model'] == admin:
                    data['model'].objects.create(email=data['email'], password=hashed_pw)
                else:
                    data['model'].objects.create(
                        correo=data['email'], 
                        password=hashed_pw,
                        nombreCajero='Cajero - Camilo',
                        salario=0.0,
                        totalEarning=0.0
                    )
                print(f"✓ Usuario {data['email']} creado exitosamente.")
        except Exception as e:
            print(f"✗ Error con {data['email']}: {e}")

if __name__ == '__main__':
    create_or_update_users()
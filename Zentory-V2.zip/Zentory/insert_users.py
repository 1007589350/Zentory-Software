@@ -0,0 +1,36 @@
#!/usr/bin/env python
import os
import django
import sys

# Configurar Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'market.settings')
django.setup()

from app.models import admin, Cajero
from django.contrib.auth.hashers import make_password

# Insertar administrador
try:
    admin_user = admin.objects.create(
        email='caansobu2@gmail.com',
        password='1234'
    )
    print(f"✓ Administrador creado: {admin_user.email} (ID: {admin_user.id})")
except Exception as e:
    print(f"✗ Error al crear administrador: {e}")

# Insertar cajero
try:
    cajero_user = Cajero.objects.create(
        nombreCajero='Cajero - Camilo',
        correo='camilosolerbu@gmail.com',
        password='1234',
        salario=0.0,
        totalEarning=0.0
    )
    print(f"✓ Cajero creado: {cajero_user.correo} (ID: {cajero_user.idCajero})")
except Exception as e:
    print(f"✗ Error al crear cajero: {e}")

print("\n¡Usuarios insertados exitosamente!")
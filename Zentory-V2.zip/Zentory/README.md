# Zentory

**Proceso de instalacion del Software**

Para este proceso se requiere tener las siguientes aplicaciones.

-   Git

-   Python (preferiblemente entre las versiones 3.7 a 3.11)

Lo primero es hacer descargar el codigo en zip
~~~
  code Download ZIP
~~~
Ahora Abre la terminal en VS Code asegúrate de estar dentro de la carpeta del proyecto Zentory
y ejecuta

  python -m venv myenv
  
Ahora que la carpeta existe, actívala

  .\myenv\Scripts\activate
~~~
Si sale algun problema con politicas ejecuta desde powershell como administrador
~~~
  Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
~~~
Una vez activado (verás que dice (myenv) a la izquierda en la terminal), debes instalar Django y las demás librerías que el proyecto necesita para funcionar:

  pip install -r requirements.txt

finalmente, corremos el siguiente comando en la terminal donde se viene
trabajando
~~~
  python manage.py runserver
~~~
De esta manera se ejecuta el proyecto en su entorno local por lo cual
desde cualquier navegador web ingresamos a la siguiente url:
~~~
  localhost:8000/
~~~

los usuarios de acceso para el software inicialmente son:

Administrador:
~~~
  correo: caansobu2@gmail.com

  clave: 1234
~~~
Cajero:
~~~
  correo: camilosolerbu@gmail.com

  clave: 1234
~~~
